package com.training.courseservice1;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

//@SpringBootTest
class CourseService1ApplicationTests {

	@Test
	void contextLoads() {
	}

}
